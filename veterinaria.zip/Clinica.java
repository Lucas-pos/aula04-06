package questãoPoo;

import java.util.ArrayList;

public class Clinica {
    private ArrayList<animal> listaAnimais;

    public Clinica() {
        listaAnimais = new ArrayList<>();
    }

    
    public boolean existeAnimal(String nome, String nomeDono) {
        for (animal a : listaAnimais) {
            if (a.getNome().equalsIgnoreCase(nome) && a.getNomeDono().equalsIgnoreCase(nomeDono)) {
                return true;
            }
        }
        return false;
    }

    
    public boolean adicionarAnimal(animal animal) {
        if (!existeAnimal(animal.getNome(), animal.getNomeDono())) {
            listaAnimais.add(animal);
            return true;
        } else {
            System.out.println("Animal já cadastrado!");
            return false;
        }
    }

    
    public boolean removerAnimal(String nome, String nomeDono) {
        for (animal a : listaAnimais) {
            if (a.getNome().equalsIgnoreCase(nome) && a.getNomeDono().equalsIgnoreCase(nomeDono)) {
                listaAnimais.remove(a);
                return true;
            }
        }
        return false;
    }

  
    public int contarAnimaisPorTipo(String tipo) {
        int contador = 0;
        for (animal a : listaAnimais) {
            if (a.getTipo().equalsIgnoreCase(tipo)) {
                contador++;
            }
        }
        return contador;
    }
}
