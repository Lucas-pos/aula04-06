package questãoPoo;

public class Main {
    public static void main(String[] args) {
        Clinica clinica = new Clinica();

        animal animal1 = new animal("Rex", "Cachorro", 5, "João");
        animal animal2 = new animal("Mimi", "Gato", 3, "Maria");
        animal animal3 = new animal("Rex", "Cachorro", 4, "João"); 

        clinica.adicionarAnimal(animal1);
        clinica.adicionarAnimal(animal2);
        clinica.adicionarAnimal(animal3); 

        System.out.println("Quantidade de gatos: " + clinica.contarAnimaisPorTipo("Gato"));

        boolean removido = clinica.removerAnimal("Rex", "João");
        System.out.println("Animal removido? " + removido);
    }
}
