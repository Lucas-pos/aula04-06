package questãoPoo;

public class animal {
    private String nome;
    private String tipo; 
    private int idade;
    private String nomeDono;

    public animal(String nome, String tipo, int idade, String nomeDono) {
        this.nome = nome;
        this.tipo = tipo;
        this.idade = idade;
        this.nomeDono = nomeDono;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public int getIdade() {
        return idade;
    }

    public String getNomeDono() {
        return nomeDono;
    }
}

